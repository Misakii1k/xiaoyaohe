import{x as e}from"./llmConfig-CWJ8NAIR.js";const i=new Set,a={"medicine-photo":"药盒或票据图片",prescription:"处方、药单图片或用药文本","work-data":"工资、班次和工时信息"};async function p(o,t){const r=new URL(t).origin,n=`${o}:${r}`;if(i.has(n))return;if(!await e(`即将把${a[o]}发送到：
${r}

数据由你选择的 AI 服务商处理。请确认其隐私政策后继续。`,"同意并继续"))throw new Error("已取消发送到 AI 服务");i.add(n)}export{p as r};
